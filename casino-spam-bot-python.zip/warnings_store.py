"""Простое персистентное хранилище предупреждений — JSON-файл на диске."""

import json
import os
import time

from typing import Optional

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_DATA_FILE = os.path.join(_BASE_DIR, 'data', 'warnings.json')


def _ensure_file():
    os.makedirs(os.path.dirname(_DATA_FILE), exist_ok=True)
    if not os.path.exists(_DATA_FILE):
        with open(_DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump({}, f)


def _load_all() -> dict:
    _ensure_file()
    with open(_DATA_FILE, 'r', encoding='utf-8') as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def _save_all(data: dict) -> None:
    _ensure_file()
    with open(_DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def _key(guild_id, user_id) -> str:
    return f'{guild_id}_{user_id}'


def get_warnings(guild_id, user_id, reset_after_days: Optional[int] = None) -> int:
    data = _load_all()
    entry = data.get(_key(guild_id, user_id))
    if not entry:
        return 0

    if reset_after_days:
        ms_since_last = time.time() * 1000 - entry.get('last_warning_at', 0)
        reset_ms = reset_after_days * 24 * 60 * 60 * 1000
        if ms_since_last > reset_ms:
            return 0

    return entry.get('count', 0)


def add_warning(guild_id, user_id) -> int:
    data = _load_all()
    key = _key(guild_id, user_id)
    entry = data.get(key, {'count': 0})
    entry['count'] = entry.get('count', 0) + 1
    entry['last_warning_at'] = time.time() * 1000
    data[key] = entry
    _save_all(data)
    return entry['count']


def reset_warnings(guild_id, user_id) -> None:
    data = _load_all()
    key = _key(guild_id, user_id)
    if key in data:
        del data[key]
        _save_all(data)

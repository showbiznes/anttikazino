"""
Детектор спам-рассылок казино/гэмблинга.
Логика зеркалит Node.js-версию: нормализация текста (разделители между буквами,
похожие символы разных алфавитов) + проверка по ключевым словам и регуляркам из config.json.
"""

import re

# Частая уловка спамеров — разделители между буквами: "к-а-з-и-н-о", "c a s i n o"
_SEPARATOR_RE = re.compile(r'([a-zа-яё])[\s._\-*]+(?=[a-zа-яё])', re.IGNORECASE)

# Похожие по написанию символы разных алфавитов (гомоглифы), которыми обходят фильтры
_HOMOGLYPHS = {
    'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
    'і': 'i', 'ѕ': 's', '0': 'o', '3': 'e', '1': 'i', '4': 'a',
    '@': 'a', '$': 's',
}
_HOMOGLYPH_RE = re.compile('[аеорсухі0-9@$]')

INVITE_LINK_RE = re.compile(r'(discord\.gg|discord\.com/invite)/\w+', re.IGNORECASE)


def normalize_text(text: str) -> str:
    if not text:
        return ''

    normalized = text.lower()
    normalized = _SEPARATOR_RE.sub(lambda m: m.group(1), normalized)
    normalized = _HOMOGLYPH_RE.sub(lambda m: _HOMOGLYPHS.get(m.group(0), m.group(0)), normalized)
    return normalized


class SpamDetector:
    def __init__(self, config: dict):
        self.keywords = [k.lower() for k in config.get('keywords', [])]
        self.regex_patterns = [re.compile(p, re.IGNORECASE) for p in config.get('regexPatterns', [])]
        self.whitelisted_domains = config.get('whitelistedDomains', [])

    def check(self, raw_content: str) -> dict:
        """Возвращает {'is_spam': bool, 'reason': str | None}"""
        if not raw_content or not raw_content.strip():
            return {'is_spam': False, 'reason': None}

        normalized = normalize_text(raw_content)

        # 1. Проверка по ключевым словам
        for keyword in self.keywords:
            if keyword in normalized:
                return {'is_spam': True, 'reason': f'ключевое слово: "{keyword}"'}

        # 2. Проверка по регуляркам (более сложные шаблоны рассылок)
        for pattern in self.regex_patterns:
            if pattern.search(raw_content) or pattern.search(normalized):
                return {'is_spam': True, 'reason': f'шаблон рассылки ({pattern.pattern})'}

        # 3. Массовая рассылка ссылок-приглашений в купе с казино-контекстом
        links = [m.group(0) for m in INVITE_LINK_RE.finditer(raw_content)]
        if links:
            is_whitelisted = bool(self.whitelisted_domains) and all(
                any(domain in link for domain in self.whitelisted_domains) for link in links
            )
            has_casino_context = any(k in normalized for k in self.keywords)
            if not is_whitelisted and has_casino_context:
                return {'is_spam': True, 'reason': 'ссылка-приглашение + казино-контекст'}

        return {'is_spam': False, 'reason': None}

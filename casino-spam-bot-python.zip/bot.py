"""
Discord-бот для обнаружения и удаления спам-рассылок казино/гэмблинга.
3 предупреждения -> мут (timeout) на N минут (по умолчанию 60).
"""

import asyncio
import json
import os
from datetime import timedelta

import discord
from dotenv import load_dotenv

import warnings_store
import ocr
from spam_detector import SpamDetector

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(BASE_DIR, 'config.json'), 'r', encoding='utf-8') as f:
    config = json.load(f)

detector = SpamDetector(config)

TOKEN = os.getenv('DISCORD_TOKEN')
if not TOKEN:
    raise SystemExit('Ошибка: не найден DISCORD_TOKEN в переменных окружения (.env файл).')

intents = discord.Intents.default()
intents.message_content = True
intents.members = True

client = discord.Client(intents=intents)


def get_log_channel(guild: discord.Guild):
    name = config.get('logChannelName')
    if not name:
        return None
    for channel in guild.text_channels:
        if channel.name == name:
            return channel
    return None


async def send_log(guild: discord.Guild, embed: discord.Embed):
    channel = get_log_channel(guild)
    if channel:
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass


async def check_image_attachments(message: discord.Message) -> dict:
    """Проверяет вложения-картинки через OCR. Возвращает результат в том же формате, что и detector.check()."""
    if not config.get('scanImages'):
        return {'is_spam': False}

    max_size = config.get('maxImageSizeBytes')
    image_attachments = [
        a for a in message.attachments
        if (a.content_type or '').startswith('image/') and (not max_size or a.size <= max_size)
    ]
    if not image_attachments:
        return {'is_spam': False}

    limit = config.get('maxImageAttachmentsPerMessage', 3)
    languages = tuple(config.get('imageOcrLanguages', ['eng', 'rus']))

    for attachment in image_attachments[:limit]:
        # requests — блокирующая библиотека, выносим в отдельный поток, чтобы не блокировать event loop бота
        text = await asyncio.to_thread(ocr.extract_text_from_image, attachment.url, languages)
        if not text or len(text.strip()) < 3:
            continue

        result = detector.check(text)
        if result['is_spam']:
            return {
                'is_spam': True,
                'reason': f"OCR-текст на картинке → {result['reason']}",
                'attachment_url': attachment.url,
                'ocr_text': text,
            }

    return {'is_spam': False}


@client.event
async def on_ready():
    print(f'✅ Бот запущен как {client.user}')


@client.event
async def on_message(message: discord.Message):
    try:
        if message.author.bot or message.guild is None:
            return

        ignored_channels = config.get('ignoredChannelIds') or []
        if message.channel.id in ignored_channels:
            return

        member = message.author if isinstance(message.author, discord.Member) else None
        ignored_roles = config.get('ignoredRoleIds') or []
        if member and ignored_roles and any(role.id in ignored_roles for role in member.roles):
            return

        result = detector.check(message.content)

        # Если по тексту сообщения спам не найден — проверяем прикреплённые картинки через OCR
        if not result['is_spam'] and message.attachments:
            image_result = await check_image_attachments(message)
            if image_result['is_spam']:
                result = image_result

        if not result['is_spam']:
            return

        # 1. Удаляем сообщение
        if config.get('deleteDetectedMessages', True):
            try:
                await message.delete()
            except discord.HTTPException as e:
                print('Не удалось удалить сообщение:', e)

        # 2. Считаем предупреждения
        guild_id = message.guild.id
        user_id = message.author.id
        warnings_count = warnings_store.add_warning(guild_id, user_id)
        threshold = config.get('warningsBeforeMute', 3)

        embed = discord.Embed(
            title='🎰 Обнаружена спам-рассылка (казино/гэмблинг)',
            color=0xED4245 if warnings_count >= threshold else 0xFAA61A,
            timestamp=discord.utils.utcnow(),
        )
        embed.add_field(name='Пользователь', value=f'<@{user_id}> ({message.author})', inline=True)
        embed.add_field(name='Канал', value=f'<#{message.channel.id}>', inline=True)
        embed.add_field(name='Причина', value=result.get('reason') or '—', inline=False)
        embed.add_field(name='Предупреждений', value=f'{warnings_count}/{threshold}', inline=True)
        embed.add_field(
            name='Текст сообщения',
            value=(message.content[:500] if message.content else '(текста нет — сработало на картинке)'),
            inline=False,
        )
        if result.get('ocr_text'):
            embed.add_field(
                name='Текст, распознанный на картинке (OCR)',
                value=result['ocr_text'][:500],
                inline=False,
            )
        if result.get('attachment_url'):
            embed.set_image(url=result['attachment_url'])

        # 3. Уведомляем пользователя в личку (не критично, если ЛС закрыты)
        try:
            if warnings_count < threshold:
                await message.author.send(
                    f"⚠️ Ваше сообщение на сервере **{message.guild.name}** было удалено — "
                    f"оно похоже на спам-рекламу казино/ставок.\n"
                    f"Это предупреждение {warnings_count} из {threshold}. "
                    f"После {threshold}-го предупреждения вы будете временно замучены на "
                    f"{config.get('muteDurationMinutes', 60)} минут."
                )
        except discord.HTTPException:
            pass

        # 4. Если достигнут порог — мутим (timeout)
        if warnings_count >= threshold:
            duration_minutes = config.get('muteDurationMinutes', 60)

            if member is not None:
                try:
                    await member.timeout(
                        timedelta(minutes=duration_minutes),
                        reason='Автомодерация: спам-рассылка казино (3 предупреждения)',
                    )
                    warnings_store.reset_warnings(guild_id, user_id)

                    try:
                        await message.author.send(
                            f"🔇 Вы получили мут на {duration_minutes} минут на сервере "
                            f"**{message.guild.name}** за повторную спам-рассылку казино/ставок."
                        )
                    except discord.HTTPException:
                        pass

                    embed.add_field(
                        name='Действие',
                        value=f'🔇 Пользователь замучен на {duration_minutes} мин.',
                        inline=False,
                    )
                except discord.Forbidden:
                    embed.add_field(
                        name='Действие',
                        value='❌ Не удалось замутить (нет прав / роль выше бота)',
                        inline=False,
                    )
                except discord.HTTPException as e:
                    embed.add_field(name='Действие', value=f'❌ Ошибка мута: {e}', inline=False)
            else:
                embed.add_field(
                    name='Действие',
                    value='❌ Не удалось получить участника сервера для мута',
                    inline=False,
                )
        else:
            embed.add_field(name='Действие', value='🗑️ Сообщение удалено, выдано предупреждение', inline=False)

        await send_log(message.guild, embed)
    except Exception as e:
        print('Ошибка обработки сообщения:', e)


client.run(TOKEN)

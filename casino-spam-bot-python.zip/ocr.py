"""
Распознавание текста на изображениях через облачный сервис OCR.space.

Почему не pytesseract/tesseract: pytesseract требует установленный в системе
бинарник tesseract-ocr, а не просто pip-пакет. На многих хостингах ботов
(включая некоторые Docker-сборщики) нет возможности доустановить системные
пакеты — сборка образа падает. OCR.space работает через обычный HTTP-запрос
с URL картинки, поэтому не требует ничего, кроме библиотеки requests.

Бесплатный демо-ключ 'helloworld' имеет очень маленький лимит запросов и
может блокироваться при активном использовании. Получите свой бесплатный
ключ на https://ocr.space/ocrapi (регистрация в одну строку, без карты)
и укажите его в .env как OCR_SPACE_API_KEY — так будет надёжнее.
"""

import os
import requests

OCR_SPACE_ENDPOINT = 'https://api.ocr.space/parse/imageurl'
_DEFAULT_DEMO_API_KEY = 'helloworld'


def extract_text_from_image(image_url: str, languages=('eng', 'rus'), timeout: int = 20) -> str:
    api_key = os.getenv('OCR_SPACE_API_KEY', _DEFAULT_DEMO_API_KEY)

    collected_text = []
    for lang in languages:
        try:
            response = requests.get(
                OCR_SPACE_ENDPOINT,
                params={
                    'apikey': api_key,
                    'url': image_url,
                    'language': lang,
                    'OCREngine': 1,
                },
                timeout=timeout,
            )
            response.raise_for_status()
            data = response.json()
        except Exception:
            # сеть недоступна / таймаут / сервис недоступен — просто пропускаем эту картинку
            continue

        if data.get('IsErroredOnProcessing'):
            continue

        for result in data.get('ParsedResults') or []:
            text = result.get('ParsedText', '')
            if text:
                collected_text.append(text)

    return '\n'.join(collected_text).strip()
